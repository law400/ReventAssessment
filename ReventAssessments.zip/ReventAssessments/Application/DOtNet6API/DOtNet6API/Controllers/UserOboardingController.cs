﻿using DataAccess.Data;
using DataAccess.Models.Utilities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Serilog;
using Serilog.Events;
using System.Reflection;

namespace DOtNet6API.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class UserOboardingController : ControllerBase
    {
        private IuserOboarding _UserOnboardingAppService;

        private readonly IConfiguration _configuration;
        public UserOboardingController(IuserOboarding UserOnboardingAppService, IConfiguration configuration)
        {
            _UserOnboardingAppService = UserOnboardingAppService;

            _configuration = configuration;
            Log.Logger = new LoggerConfiguration()
                               .MinimumLevel.Debug()
                               .MinimumLevel.Override("Microsoft", LogEventLevel.Warning)
                               .Enrich.FromLogContext()

                               .WriteTo.File(@"C:\reventlog\LogFile.txt")
                               //.WriteTo.File( _configuration.GetSection("LogFolder:LogPath").Value)
            .CreateLogger();

        }


        [AllowAnonymous]
        [HttpPost("RegisterUser")]
        public async Task<IActionResult> AddUser(UserModel model)
        {
            try
            {

                Log.Information("input parameters New registration   starts..... : ");
                Log.Information(string.Format("UserName {0}\r\nEmail: {1}\r\nphonenumber: {2}\r\n FirstName :{3}\r\nMiddleName : {4}\r\nLastName : {5}\r\n", model.UserName, model.Email, model.phonenumber, model.FirstName, model.MiddleName, model.LastName));


                var returnMessage = new ReturnMessage();
               returnMessage = await _UserOnboardingAppService.CreateUser(model);

                if (returnMessage.outputval == 0)

                {
                    return Ok(returnMessage);
                }
                else
                {

                    return Ok(returnMessage);

                }


            }
            catch (Exception ex)
            {
                Log.Fatal(string.Format("Error occured {0}", ex.Message));
                return null;
            }
        }


       
        [HttpPost("UpdateUser")]
        public async Task<IActionResult> UpdateUser(UserModel model)
        {
            try
            {
                Log.Information("input parameters listfor update  starts..... : " ); 
                Log.Information(string.Format("UserName {0}\r\nEmail: {1}\r\nphonenumber: {2}\r\n FirstName :{3}\r\nMiddleName : {4}\r\nLastName : {5}\r\n", model.UserName, model.Email, model.phonenumber, model.FirstName, model.MiddleName, model.LastName));

                var returnMessage = new ReturnMessage();
                returnMessage = await _UserOnboardingAppService.UpdateUser(model);

                if (returnMessage.outputval == 0)

                {
                    return Ok(returnMessage);
                }
                else
                {

                    return Ok(returnMessage);

                }


            }
            catch (Exception ex)
            {
                Log.Fatal(string.Format("Error occured {0}", ex.Message));
                return null;
            }
        }

        [HttpPost("CheckIfUserExist")]
        public async Task<IActionResult> CheckIfUserExist(CheckIFUserExistModel model )
        {
            try
            {

                Log.Information("input parameter(s)  to check if user exist..... : ");
                Log.Information(string.Format("UserName {0}", model.UserName));

                var returnMessage = new ReturnMessage();
                returnMessage = await _UserOnboardingAppService.CheckIfUserExist(model);

                if (returnMessage.outputval == 0)

                {
                    return Ok(returnMessage);
                }
                else
                {

                    return Ok(returnMessage);

                }


            }
            catch (Exception ex)
            {
                Log.Fatal(string.Format("Error occured {0}", ex.Message));
                return null;
            }
        }

        [HttpPost("DeleteUser")]
        public async Task<IActionResult> DeleteUser(DeleteUserModel model)
        {
            try
            {

                Log.Information("input parameter(s)  to check if user exist before attempting to delete..... : ");
                Log.Information(string.Format("UserName {0}", model.UserName));
                var returnMessage = new ReturnMessage();
                returnMessage = await _UserOnboardingAppService.DeleteUser(model);

                if (returnMessage.outputval == 0)

                {
                    return Ok(returnMessage);
                }
                else
                {

                    return Ok(returnMessage);

                }


            }
            catch (Exception ex)
            {
                Log.Fatal(string.Format("Error occured {0}", ex.Message));
                return null;
            }
        }



        [Authorize]
        [HttpGet("GetUserbyUsername")]
        public async Task<IActionResult> GetUsersByUsername(string Username)
        {
            try
            {
                Log.Information("input parameter(s)  to get user by username..... : ");
                Log.Information(string.Format("UserName {0}", Username));
                var returnMessage = new ReturnMessage();
                var response  = await _UserOnboardingAppService.GetUsersByUsername(Username);

               
                    return Ok(response);
               


            }
            catch (Exception ex)
            {
                Log.Fatal(string.Format("Error occured {0}", ex.Message));
                return null;
            }
        }
        [Authorize]
        [HttpGet("GetAllUsers")]
        public async Task<IActionResult> GetAllUsers()
        {
            try
            {
                Log.Information("Get all users users starts here ..... : ");
            
                var returnMessage = new ReturnMessage();
                var response = await _UserOnboardingAppService.GetAllUsers();
               

                return Ok(response);



            }
            catch (Exception ex)
            {
                Log.Fatal(string.Format("Error occured {0}", ex.Message));
                return null;
            }
        }
    }
}
