﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Models
{
    public class UserModel
    {

      
        public string UserName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string phonenumber { get; set; } = string.Empty;
        public string FirstName { get; set; } = string.Empty;
        public string MiddleName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
    }


    public class CheckIFUserExistModel
    {


        public string UserName { get; set; } = string.Empty;
       
    }

    public class DeleteUserModel
    {


        public string UserName { get; set; } = string.Empty;

    }
    public class UserByUsernameModel
    {


        public string UserName { get; set; } = string.Empty;

    }

    //public class User
    //{
    //    public string username { get; set; }
    //    //public string password { get; set; }
    //}
}
