﻿using DataAccess.Models;
using DataAccess.Models.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Data
{
    public interface IuserOboarding
    {
        Task<ReturnMessage> CreateUser(UserModel Model);
        Task<ReturnMessage> UpdateUser(UserModel Model);
        Task<ReturnMessage> CheckIfUserExist(CheckIFUserExistModel Model);
        Task<ReturnMessage> DeleteUser(DeleteUserModel Model);
        Task<UserModel> GetUsersByUsername(string Username);
        Task<UserModel> GetAllUsers();

    }
}
