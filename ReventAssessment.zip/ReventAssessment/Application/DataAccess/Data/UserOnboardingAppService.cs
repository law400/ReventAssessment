﻿using Dapper;
using DataAccess.Dapper;
using DataAccess.Models.Utilities;
using DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess.DbAccess;
using System.Collections.Generic;

using System.Threading.Tasks;

namespace DataAccess.Data
{
    public  class UserOnboardingAppService : IuserOboarding
    {


        private readonly DapperContext _dapperContext;
        
        public UserOnboardingAppService( DapperContext dapperContext)
        {
            _dapperContext = dapperContext;
         
        }

        public async Task<ReturnMessage>  CreateUser(UserModel Model)
        {
            var returnmessage = new ReturnMessage();
           
            string procName =   "Proc_RegisternewUser";
            var param = new DynamicParameters();

            param.Add("@UserName", Model.UserName);
            param.Add("@Email", Model.Email);
            param.Add("@PhoneNumber", Model.phonenumber);
            param.Add("@FirstName", Model.FirstName);
            param.Add("@MiddleName", Model.MiddleName);
            param.Add("@LastName", Model.LastName);
            param.Add("@retval", dbType: DbType.Int32, direction: ParameterDirection.Output);
            param.Add("@retMsg", dbType: DbType.String, direction: ParameterDirection.Output, size: DbString.DefaultLength);

            try
            {


                SqlMapper.Execute(_dapperContext.CreateConnection(),
                procName, param, commandType: CommandType.StoredProcedure);

                returnmessage.outputval = param.Get<int>("@retval");
                returnmessage.outputmessage = param.Get<string>("@retMsg");

                if (returnmessage.outputval == 0)//check if the executed succeessfully
                {


                    returnmessage.outputmessage =  returnmessage.outputmessage;

                    return returnmessage;
                }
                else
                {
                    returnmessage.outputmessage =  returnmessage.outputmessage;
                    return returnmessage;
                }
            }
            catch (Exception ex)
            {
              
                returnmessage.outputmessage = ex.Message;

                return returnmessage;
            }
        }



        public async Task<ReturnMessage> UpdateUser(UserModel Model)
        {
            var returnmessage = new ReturnMessage();

            string procName = "Proc_UpdateUser";
            var param = new DynamicParameters();

            param.Add("@UserName", Model.UserName);
            param.Add("@Email", Model.Email);
            param.Add("@PhoneNumber", Model.phonenumber);
            param.Add("@FirstName", Model.FirstName);
            param.Add("@MiddleName", Model.MiddleName);
            param.Add("@LastName", Model.LastName);
            param.Add("@retval", dbType: DbType.Int32, direction: ParameterDirection.Output);
            param.Add("@retMsg", dbType: DbType.String, direction: ParameterDirection.Output, size: DbString.DefaultLength);

            try
            {


                SqlMapper.Execute(_dapperContext.CreateConnection(),
                procName, param, commandType: CommandType.StoredProcedure);

                returnmessage.outputval = param.Get<int>("@retval");
                returnmessage.outputmessage = param.Get<string>("@retMsg");

                if (returnmessage.outputval == 0)//check if the executed succeessfully
                {


                    returnmessage.outputmessage = returnmessage.outputmessage;

                    return returnmessage;
                }
                else
                {
                    returnmessage.outputmessage = returnmessage.outputmessage;
                    return returnmessage;
                }
            }
            catch (Exception ex)
            {

                returnmessage.outputmessage = ex.Message;

                return returnmessage;
            }
        }

        public async Task<ReturnMessage> CheckIfUserExist(CheckIFUserExistModel Model)
        {
            var returnmessage = new ReturnMessage();

            string procName = "Proc_CheckIfUserExist";
            var param = new DynamicParameters();

            param.Add("@UserName", Model.UserName);
           
            param.Add("@retval", dbType: DbType.Int32, direction: ParameterDirection.Output);
            param.Add("@retMsg", dbType: DbType.String, direction: ParameterDirection.Output, size: DbString.DefaultLength);

            try
            {


                SqlMapper.Execute(_dapperContext.CreateConnection(),
                procName, param, commandType: CommandType.StoredProcedure);

                returnmessage.outputval = param.Get<int>("@retval");
                returnmessage.outputmessage = param.Get<string>("@retMsg");

                if (returnmessage.outputval == 0)//check if the executed succeessfully
                {


                    returnmessage.outputmessage = returnmessage.outputmessage;

                    return returnmessage;
                }
                else
                {
                    returnmessage.outputmessage = returnmessage.outputmessage;
                    return returnmessage;
                }
            }
            catch (Exception ex)
            {

                returnmessage.outputmessage = ex.Message;

                return returnmessage;
            }
        }

        public async Task<ReturnMessage> DeleteUser(DeleteUserModel Model)
        {
            var returnmessage = new ReturnMessage();

            string procName = "Proc_DeleteUser";
            var param = new DynamicParameters();

            param.Add("@UserName", Model.UserName);

            param.Add("@retval", dbType: DbType.Int32, direction: ParameterDirection.Output);
            param.Add("@retMsg", dbType: DbType.String, direction: ParameterDirection.Output, size: DbString.DefaultLength);

            try
            {


                SqlMapper.Execute(_dapperContext.CreateConnection(),
                procName, param, commandType: CommandType.StoredProcedure);

                returnmessage.outputval = param.Get<int>("@retval");
                returnmessage.outputmessage = param.Get<string>("@retMsg");

                if (returnmessage.outputval == 0)//check if the executed succeessfully
                {


                    returnmessage.outputmessage = returnmessage.outputmessage;

                    return returnmessage;
                }
                else
                {
                    returnmessage.outputmessage = returnmessage.outputmessage;
                    return returnmessage;
                }
            }
            catch (Exception ex)
            {

                returnmessage.outputmessage = ex.Message;

                return returnmessage;
            }
        }

      
        public async Task<UserModel> GetUsersByUsername(string Username )

        {

            var SqlQuery = @"select UserName,Email,phonenumber, FirstName,MiddleName,LastName from reventUsername  where username  = @username";

            using (var connection = _dapperContext.CreateConnection())
            {
                var processlist = await connection.QueryAsync<UserModel>(SqlQuery, new { Username });
            return  processlist.FirstOrDefault();
            }
        }

        public async Task<UserModel> GetAllUsers()

        {

            var SqlQuery = @"select UserName,Email,phonenumber, FirstName,MiddleName,LastName from reventUsername";

            
            using (var connection = _dapperContext.CreateConnection())
            {
                var processlist = await connection.QueryAsync<UserModel>(SqlQuery, new { });

               

                return processlist.FirstOrDefault();
            }
        }


        
    }
}
