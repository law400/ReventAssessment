﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Models.Utilities
{
    //public class AppUtilities
    //{


    //}

    public class ReturnMessage
    {

        public string outputmessage { get; set; } 
        public int outputval { get; set; }

    }
}
