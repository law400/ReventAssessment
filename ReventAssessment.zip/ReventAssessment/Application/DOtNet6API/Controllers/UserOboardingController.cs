﻿using DataAccess.Data;
using DataAccess.Models.Utilities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Serilog;
using Serilog.Events;
namespace DOtNet6API.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class UserOboardingController : ControllerBase
    {
        private IuserOboarding _UserOnboardingAppService;

        private readonly IConfiguration _configuration;
        public UserOboardingController(IuserOboarding UserOnboardingAppService, IConfiguration configuration)
        {
            _UserOnboardingAppService = UserOnboardingAppService;

            _configuration = configuration;
            Log.Logger = new LoggerConfiguration()
                               .MinimumLevel.Debug()
                               .MinimumLevel.Override("Microsoft", LogEventLevel.Warning)
                               .Enrich.FromLogContext()
                            
                               .WriteTo.File( _configuration.GetSection("LogFolder:LogPath").Value)
            .CreateLogger();

        }


        [AllowAnonymous]
        [HttpPost("RegisterUser")]
        public async Task<IActionResult> AddUser(UserModel model)
        {
            try
            {

                Log.Information("input parameters list : " + model.FirstName);

                var returnMessage = new ReturnMessage();
               returnMessage = await _UserOnboardingAppService.CreateUser(model);

                if (returnMessage.outputval == 0)

                {
                    return Ok(returnMessage);
                }
                else
                {

                    return Ok(returnMessage);

                }


            }
            catch (Exception ex)
            {
                return null;
            }
        }


        [Authorize]
        [HttpPost("UpdateUser")]
        public async Task<IActionResult> UpdateUser(UserModel model)
        {
            try
            {
                Log.Information("input parameters list : " + model.FirstName);
                var returnMessage = new ReturnMessage();
                returnMessage = await _UserOnboardingAppService.UpdateUser(model);

                if (returnMessage.outputval == 0)

                {
                    return Ok(returnMessage);
                }
                else
                {

                    return Ok(returnMessage);

                }


            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [HttpPost("CheckIfUserExist")]
        public async Task<IActionResult> CheckIfUserExist(CheckIFUserExistModel model )
        {
            try
            {
                var returnMessage = new ReturnMessage();
                returnMessage = await _UserOnboardingAppService.CheckIfUserExist(model);

                if (returnMessage.outputval == 0)

                {
                    return Ok(returnMessage);
                }
                else
                {

                    return Ok(returnMessage);

                }


            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [HttpPost("DeleteUser")]
        public async Task<IActionResult> DeleteUser(DeleteUserModel model)
        {
            try
            {
                var returnMessage = new ReturnMessage();
                returnMessage = await _UserOnboardingAppService.DeleteUser(model);

                if (returnMessage.outputval == 0)

                {
                    return Ok(returnMessage);
                }
                else
                {

                    return Ok(returnMessage);

                }


            }
            catch (Exception ex)
            {
                return null;
            }
        }




        [HttpGet("GetUserbyUsername")]
        public async Task<IActionResult> GetUsersByUsername(string Username)
        {
            try
            {
                var returnMessage = new ReturnMessage();
                var response  = await _UserOnboardingAppService.GetUsersByUsername(Username);

               
                    return Ok(response);
               


            }
            catch (Exception ex)
            {
                return null;
            }
        }
        [Authorize]
        [HttpGet("GetAllUsers")]
        public async Task<IActionResult> GetAllUsers()
        {
            try
            {
                var returnMessage = new ReturnMessage();
                var response = await _UserOnboardingAppService.GetAllUsers();


                return Ok(response);



            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }
}
