﻿namespace DOtNet6API
{
    public interface IJwtAuthenticationManager
    {
        string Authenticate(string username, string password);

       
    }
}
